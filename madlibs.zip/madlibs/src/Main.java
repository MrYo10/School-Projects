import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in); //initiates scanner item

         System.out.println("Hello and Welcome to the MADLIBS GAME");
         System.out.println("Please provide the following details i will request from you so we can play the game!");

         //game questions
        //name
        System.out.println("PLease enter your name!: ");
        String name = scanner.nextLine();

        //Asjetive
        System.out.println("Enter an adjective: ");
        String adjective = scanner.nextLine();

        //place
        System.out.println("Enter a place: ");
        String place = scanner.nextLine();

        //numbers

        System.out.println("Enter your first number: ");
        int firstNumber = scanner.nextInt();

        System.out.println("Enter your second number: ");
        int secondNumber = scanner.nextInt();

        System.out.println("Enter your third number: ");
        int thirdNumber = scanner.nextInt();

        //Math Operations

        int sum = firstNumber + secondNumber + thirdNumber;
        double squareRoot = Math.sqrt(sum);

        // Print the first part of the story
        System.out.println("\nHere's your story:");
        System.out.println(name + " was a very " + adjective + " who always wanted to go to " + place + ".");
        System.out.println("One day, they decided to explore the unknown parts of " + place + " .");

        // Print the math results in the story
        System.out.println("\nThey brought along " + firstNumber + " supplies, " + secondNumber + " snacks, and " + thirdNumber + " bottles of water.");
        System.out.println("They quickly realized that they had a total of " + sum + " items for the trip.");
        System.out.println(name + " also decided to calculate the square root of their first number (" + firstNumber + "), which turned out to be " + squareRoot + ".");

        // End of the story
        System.out.println("\nAnd so, " + name + " and their friends had an unforgettable adventure in " + place + "!");

        // Close the scanner
        scanner.close();

    }

}
