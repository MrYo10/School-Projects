import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Task 1: Automatically check passwords from a file for validation
        try {
            BufferedReader reader = new BufferedReader(new FileReader("passwords.txt"));
            String password;
            while ((password = reader.readLine()) != null) {
                System.out.println("Checking password: " + password);
                validatePassword(password);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        // Task 2: Ask the user to enter and confirm a password
        Scanner sc = new Scanner(System.in);
        boolean passwordsMatch = false;

        while (!passwordsMatch) {
            System.out.println("\nEnter your new password:");
            String password1 = sc.nextLine();
            System.out.println("Confirm your new password:");
            String password2 = sc.nextLine();

            if (password1.equals(password2)) {
                if (validatePassword(password1)) {
                    System.out.println("New password accepted.");
                    passwordsMatch = true;
                } else {
                    System.out.println("Password did not meet the security requirements. Try again.");
                }
            } else {
                System.out.println("Passwords do not match. Please try again.");
            }
        }

        sc.close();
    }

    // User-Defined Method: Validates password and lists violations
    public static boolean validatePassword(String password) {
        boolean isValid = true;

        // Check length
        if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long.");
            isValid = false;
        }

        // Check for a numeric character
        if (!password.matches(".*\\d.*")) {
            System.out.println("Password must contain at least one numeric character.");
            isValid = false;
        }

        // Check for an uppercase letter
        if (!password.matches(".*[A-Z].*")) {
            System.out.println("Password must contain at least one uppercase letter.");
            isValid = false;
        }

        // Check for spaces
        if (password.contains(" ")) {
            System.out.println("Password must not contain spaces.");
            isValid = false;
        }

        // Check for prohibited starting characters
        if (password.startsWith("!") || password.startsWith("?")) {
            System.out.println("Password must not start with an exclamation mark (!) or question mark (?).");
            isValid = false;
        }

        return isValid;
    }
}
