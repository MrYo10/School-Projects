import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Task 1: Reading email addresses from a text file for validation
        try {
            BufferedReader reader = new BufferedReader(new FileReader("emails.txt"));
            String email1 = reader.readLine();
            String email2 = reader.readLine();
            reader.close();

            // Validate both emails from the text file
            System.out.println("Checking emails from file:");
            validateEmail(email1);
            validateEmail(email2);

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        // Task 2: Loop until a valid email address is provided
        Scanner sc = new Scanner(System.in);
        String userEmail = "";
        boolean validEmail = false;

        while (!validEmail) {
            System.out.println("\nEnter your email address:");
            userEmail = sc.nextLine();
            validEmail = validateEmail(userEmail);
            if (!validEmail) {
                System.out.println("Please enter a valid educational email address.");
            }
        }

        // Loop until the passwords match
        boolean passwordsMatch = false;
        while (!passwordsMatch) {
            System.out.println("Enter a new password:");
            String password1 = sc.nextLine();
            System.out.println("Confirm your password:");
            String password2 = sc.nextLine();
            if (password1.equals(password2)) {
                System.out.println("Password set successfully!");
                passwordsMatch = true;
            } else {
                System.out.println("Passwords do not match. Please try again.");
            }
        }

        sc.close();
    }

    // User-Defined Method: Validates an email address and prints username or error
    public static boolean validateEmail(String email) {
        if (email != null && email.contains("@") && email.endsWith(".edu")) {
            String username = email.substring(0, email.indexOf('@'));
            System.out.println("Valid educational email address. Username: " + username);
            return true;
        } else {
            System.out.println("Invalid educational email address.");
            return false;
        }
    }
}
