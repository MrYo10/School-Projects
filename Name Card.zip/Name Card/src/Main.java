

public class Main {
    public static void main(String[] args) {

        System.out.println("Gabriel silva");
        System.out.print("354 Williamson st, ");
        System.out.print("Elizabeth, NJ, ");
        System.out.println("07202");
        System.out.println("(908)-380-9223");
        System.out.println("gxs5487@psu.edu");
        System.out.println("Computer Science :)");
    }
}