import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        String[] jobs = new String[100];
        int[] salaries = new int[100];
        int count = 0;

        // Reading data from the file
        try {
            // Creating a Scanner object to read from the "careers.txt" file
            Scanner fileReader = new Scanner(new File("careers.txt"));

            // Loop to read each line of the file
            while (fileReader.hasNextLine()) {
                // Read the job title from the current line
                String job = fileReader.nextLine().trim();

                // Check the next line to see if it's a salary or part of the job title
                String nextLine = fileReader.nextLine().trim();

                // If the next line isn't a salary, continue appending to the job title
                while (!isNumeric(nextLine)) {
                    job += " " + nextLine;
                    if (fileReader.hasNextLine()) {
                        nextLine = fileReader.nextLine().trim();
                    } else {
                        // If there is no corresponding salary, print an error message
                        System.out.println("Missing salary for job: " + job);
                        return;
                    }
                }

                // Convert the salary string to an integer and store both job and salary
                try {
                    int salary = Integer.parseInt(nextLine);
                    jobs[count] = job;
                    salaries[count] = salary;
                    count++;
                } catch (NumberFormatException e) {
                    // Handle cases where salary isn't a valid number
                    System.out.println("Invalid salary for job: " + job + " -> " + nextLine);
                }
            }
            fileReader.close();
        } catch (FileNotFoundException e) {
            // Handle the case when the file isn't found
            System.out.println("File not found.");
            return;
        }

        // Sorting the jobs and salaries using bubble sort in parallel
        bubbleSort(jobs, salaries, count);

        // Displaying the sorted list of jobs and their corresponding salaries
        System.out.printf("%-50s %15s\n", "Job Title", "Salary");
        System.out.println("--------------------------------------------------------");

        // Loop to print each job and salary in a formatted way
        for (int i = 0; i < count; i++) {
            System.out.printf("%-50s %,15d\n", jobs[i], salaries[i]);
        }
    }

    // Bubble sort to sort the salaries and jobs simultaneously
    public static void bubbleSort(String[] jobs, int[] salaries, int n) {
        boolean swapped; // Variable to check if a swap occurred
        do {
            swapped = false; // Reset swap status
            for (int i = 0; i < n - 1; i++) {
                // Compare adjacent salaries, sorting in descending order
                if (salaries[i] < salaries[i + 1]) {
                    // Swap the salaries
                    int tempSalary = salaries[i];
                    salaries[i] = salaries[i + 1];
                    salaries[i + 1] = tempSalary;

                    // Swap the corresponding job titles
                    String tempJob = jobs[i];
                    jobs[i] = jobs[i + 1];
                    jobs[i + 1] = tempJob;

                    swapped = true; // Mark that a swap occurred
                }
            }
        } while (swapped); // Continue until no swaps are made
    }

    // Helper function to check if a string is numeric (used to identify salary lines)
    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str); // Try to convert the string to an integer
            return true; // If successful, the string is numeric
        } catch (NumberFormatException e) {
            return false; // If it throws an exception, the string isn't numeric
        }
    }
}
