import java.util.Scanner;

public class Main {

    // input a judge score
    public static double judgeScore(int judgeNumber) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Score for Judge " + judgeNumber + ": ");
        return scanner.nextDouble();
    }

    //accumulate total score
    public static double calculateScore(double[] scores) {
        double total = 0;
        for (double score : scores) {
            total += score;
        }
        return total;
    }

    //calculate average score
    public static void calculateAndDisplayAverage(double totalScore, int numberOfJudges) {
        double average = totalScore / numberOfJudges;
        System.out.printf("The average score is: %.2f\n", average);
    }

    public static void main(String[] args) {
        int numberOfJudges = 6;
        double[] scores = new double[numberOfJudges];


        for (int i = 0; i < numberOfJudges; i++) {
            scores[i] = judgeScore(i + 1);
        }


        double totalScore = calculateScore(scores);


        calculateAndDisplayAverage(totalScore, numberOfJudges);
    }
}
